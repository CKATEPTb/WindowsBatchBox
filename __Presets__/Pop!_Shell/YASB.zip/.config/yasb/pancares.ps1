param(
    [string]$Login       = $env:PANCARES_LOGIN,
    [string]$Password    = $env:PANCARES_PASSWORD,
    [string]$RppId    	 = $env:PANCARES_RPP_ID,
	[string]$SysTimeZone = [Windows.Globalization.Calendar,Windows.Globalization,ContentType=WindowsRuntime]::new().GetTimeZone()
)

[Console]::OutputEncoding = $OutputEncoding = [System.Text.Encoding]::UTF8

$TokenFile = "$env:TEMP\pancares_token.txt"
$Headers   = @{ "Time-Zone" = $SysTimeZone; "Version" = "eu" }

function Get-Token {
    try {
        $r = Invoke-WebRequest -UseBasicParsing -Uri "https://equil.pancares.com/api/v2/user/login" `
            -Method POST -Headers $Headers -ContentType "application/json;charset=UTF-8" `
            -Body "{`"sourceType`":0,`"userName`":`"$Login`",`"password`":`"$Password`",`"identity`":2}"
        if (($r.Content | ConvertFrom-Json).code -ne 200) { return $null }
        $t = $r.Headers["Token"]
        if ($t) { Set-Content $TokenFile $t -Encoding UTF8 }
        return $t
    } catch { return $null }
}

function Get-CGM ([string]$Token) {
    try {
        $r = Invoke-WebRequest -UseBasicParsing `
            -Uri "https://equil.pancares.com/api/v2/monitor/threeDayCgm?rppId=$RppId" `
            -Headers ($Headers + @{ Token = $Token })
        return $r.Content | ConvertFrom-Json
    } catch { return $null }
}

function Fail ([string]$msg) { @{ glucose = "N/A"; datetime = $msg } | ConvertTo-Json -Compress; exit 1 }

$token = if (Test-Path $TokenFile) { (Get-Content $TokenFile -Raw).Trim() } else { Get-Token }
if (-not $token) { Fail "Login failed" }

$cgm = Get-CGM $token
if (-not $cgm -or $cgm.code -ne 200) {
    $token = Get-Token
    if (-not $token) { Fail "Auth error" }
    $cgm = Get-CGM $token
}

if (-not $cgm -or $cgm.code -ne 200) { Fail "Fetch error" }

$last = $cgm.data | Select-Object -Last 1
if (-not $last) { Fail "No data" }

@{ glucose = $last.glucose; datetime = $last.deviceTimeStr } | ConvertTo-Json -Compress
